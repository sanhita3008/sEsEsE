package com.cognizant.stockmarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockmarketServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
